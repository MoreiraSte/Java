
public class Questao2Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Questao2 q2 = new Questao2();
		q2.escrevendo();
		q2.lendo();
		
		
		
	}

}
