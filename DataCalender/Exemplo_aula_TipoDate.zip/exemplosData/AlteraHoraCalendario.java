
import java.util.Calendar;

public class AlteraHoraCalendario{

	public static void main(String[] args) {
		
		Calendar c = Calendar.getInstance(); //Date do momento
		System.out.println("Data/Hora atual: "+ c.getTime());
		
		//Alterando data
		c.set(Calendar.YEAR, 2020); 
		c.set(Calendar.MONTH, Calendar.JANUARY); 
		c.set(Calendar.DAY_OF_MONTH, 25);
		
		//Alterando hora
		c.set(Calendar.HOUR, 10); 
		c.set(Calendar.MINUTE, 20); 
		c.set(Calendar.SECOND, 00);
		
		System.out.println("\nData/Hora atualizada: "+ c.getTime());
		System.out.println("Ano: "+ c.get(Calendar.YEAR));
		System.out.println("M�s: "+ c.get(Calendar.MONTH));
		System.out.println("Dia do M�s: "+c.get(Calendar.DAY_OF_MONTH));

		System.out.println("Hora: "+ c.get(Calendar.HOUR));
		System.out.println("Min: "+ c.get(Calendar.MINUTE));
		System.out.println("Seg: "+c.get(Calendar.SECOND));

	}

}