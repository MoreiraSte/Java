import java.util.Calendar;

public class AlteraCalendario {


	public static void main(String[] args) {
			 Calendar c = Calendar.getInstance(); //obtem uma Date do momento
			 c.set(Calendar.YEAR, 2020); 
			 c.set(Calendar.MONTH, Calendar.JANUARY); 
			 c.set(Calendar.DAY_OF_MONTH, 26);
			
			System.out.println("Data/Hora atual: "+ c.getTime());
			System.out.println("Ano: "+ c.get(Calendar.YEAR));
			System.out.println("M�s: "+ c.get(Calendar.MONTH));
			System.out.println("Dia do M�s: "+c.get(Calendar.DAY_OF_MONTH));
	}

}


