package exemplosDataMoney;

import java.util.Calendar;
import java.util.Date;

public class SomandoDatas {

	public static void main(String[] args) {

			Date hoje = new Date();
			
			//representa calendario
			Calendar cal = Calendar.getInstance();
			
			cal.setTime(hoje);
			
			// qualquer uma das opcoes serviria para alterar para amanha 
			// cal.add(Calendar.DAY_OF_WEEK, 1); 
			// cal.add(Calendar.DAY_OF_YEAR, 1); 
			cal.add(Calendar.DAY_OF_MONTH, 1);

			Date amanha = cal.getTime();
			
			System.out.println("Hoje eh: " + hoje  );
			System.out.println("Amanha eh: " + amanha  );
	}

}
