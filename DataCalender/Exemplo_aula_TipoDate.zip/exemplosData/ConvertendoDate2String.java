import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JTextField;

public class ConvertendoDate2String {

	public static void main(String[] args) {

		Date dataHoje = new Date();

		//Objeto formatador de Data e seu formato
		SimpleDateFormat sdf1= new SimpleDateFormat("dd/MM/yyyy"); //voc� pode usar outras m�scaras
		
		String dataHojeStr = sdf1.format(dataHoje);

		System.out.println("Data de hoje: "+ dataHojeStr);

//		JTextField dataHojeTextField = new JTextField();
//      obtem do VO a data e converte: sugest�o criar no VO um m�todo getDataNascFormatada()
//		dataHojeTextField.setText(dataHojeStr); // valor mostrado para usuario

		
	}

}
