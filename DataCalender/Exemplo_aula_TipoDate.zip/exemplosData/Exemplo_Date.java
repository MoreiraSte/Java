import java.util.Date;

public class Exemplo_Date {

	public static void main(String[] args) {

		// De onde o java obt�m a data
		System.out.println("Data do SO:" + System.currentTimeMillis());
		
		Date data = new Date(); // data do momento da cria��o do objeto 

		//Formata interno do tipo Date 
		System.out.print("\nData (long iniciado em 01/01/1970): " + data.getTime());
		
		//Mostrar a data
		System.out.println("\nData Agora: "+ data);

		//Alguns problemas do Date
		System.out.print("\nDia de hoje: " + data.getDay());
		System.out.print("\nMes atual: " + data.getMonth());
		
	}
}
