import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JTextField;

public class ConvertendoString2Data {

	public static void main(String[] args) {
	 	
		JTextField dataCompraTextField = new JTextField();
		dataCompraTextField.setText("02/10/2020"); // valor digitado pelo usuario
		
		String dataCompraStr = dataCompraTextField.getText();  //pegando dados de um formul�rio 
		
		SimpleDateFormat sdf1= new SimpleDateFormat("dd/MM/yyyy"); //voc� pode usar outras m�scaras
		
		try {
			Date dataCompra = sdf1.parse(dataCompraStr);
			System.out.println("Data de compra: "+ dataCompra);

		} catch (ParseException e) {
			System.out.println("Entre com uma nova data: formato ou data inv�lida");
		}
		
		System.out.println("\n\nFim da conversao de String para data");
	}
}
