import javax.swing.JFrame;

public class UsandoJCalendarTestadora {

	public static void main(String[] args) {

		UsandoJCalendar jCal= new UsandoJCalendar();
		
	//	alunoAddFrame2.setResizable(false);
		jCal.setSize( 370, 300 ); // set frame size
		
		jCal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );
		
		jCal.setVisible(true);

	}

}
