
//Programa criado por: Maria Eduarda Alves de Lima - HT3001881
package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Filme {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String nome_filme;
	private String genero;
	private int avaliacao;
	
	
	public Filme() {
		super();
	}

	public Filme(int id, String nome_filme, String genero, int avaliacao) {
		super();
		this.id = id;
		this.nome_filme = nome_filme;
		this.genero = genero;
		this.avaliacao = avaliacao;
	}
	
	public Filme(String nome_filme, String genero, int avaliacao) {
		super();
		this.nome_filme = nome_filme;
		this.genero = genero;
		this.avaliacao = avaliacao;
	}
	
	public String getNome_filme() {
		return nome_filme;
	}
	public void setNome_filme(String nome_filme) {
		this.nome_filme = nome_filme;
	}
	
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	
	
	public int getAvaliacao() {
		return avaliacao;
	}
	public void setAvaliacao(int avaliacao) {
		this.avaliacao = avaliacao;
	}
	public int getId() {
		return id;
	}
	
}
	
	

