//Programa criado por: Maria Eduarda Alves de Lima - HT3001881
package model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

// Classe que ir� acessar o banco de dados.
public class FilmeDAO {

	private EntityManagerFactory emf;
	
	public FilmeDAO(EntityManagerFactory emf) {
		super();
		this.emf = emf;
	}
	
	

	public boolean excluirFilme(int id) {

		EntityManager em = emf.createEntityManager();
		boolean result;

		try {
			Filme filme = em.find(Filme.class, id);
			em.getTransaction().begin();
			em.remove(filme);
			em.getTransaction().commit();
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
			result = false;
		} finally {
			em.close();
		}
		return result;
	}
	
	
	public Filme procurarFilme(int id) {

		Filme filme = null;
		EntityManager em = emf.createEntityManager();

		try {
			filme = em.find(Filme.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			em.close();
		}
		return filme;
		
	}

	public List<Filme> consultaFilme(){
		
		List<Filme> listaFilmes = new ArrayList<>();
		EntityManager em = emf.createEntityManager();
		
		try {
			listaFilmes = em.createQuery("FROM " + Filme.class.getName()).getResultList();
				
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			em.close();
		}
		
		return listaFilmes;
		
	}
	
	public boolean inserirFilme(String nome_filme, String genero, int avaliacao) {
		
		EntityManager em = emf.createEntityManager();
		boolean result;
		
		try {
			Filme filme = new Filme(nome_filme, genero, avaliacao);
			em.getTransaction().begin();
			em.persist(filme);
			em.getTransaction().commit();
			result = true;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		
		} finally {
			em.close();	
		}
		
		return result;
	}

}
