//Programa criado por: Maria Eduarda Alves de Lima - HT3001881
package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Filme;
import model.FilmeDAO;

@WebServlet("/FilmeController")
public class FilmeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private FilmeDAO filmesDAO;
	private EntityManagerFactory emf = Persistence.createEntityManagerFactory("filme-jpa");
	
	
	@Override
	public void init() throws ServletException {
		super.init();
		filmesDAO = new FilmeDAO(emf);
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet");
		
		String acao = request.getParameter("acao");
		
		switch (acao) {
		case "listar": {
			listarFilmes(request, response);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + acao);
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("doPost");
		String acao = request.getParameter("acao");
		acao = acao.toLowerCase();
		
		switch (acao) {
		case "cadastrar": {
			cadastrarFilme(request, response);
			break;
		}
		case "buscar": {
			buscarFilme(request, response);
			break;
		}
		case "remover": {
			removerFilme(request, response);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + acao);
		}
	}
	
	
	
	private void removerFilme (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
System.out.println("Controller: removerFilme");
		
		int id = Integer.parseInt(request.getParameter("id_filme"));
		boolean excluiu = filmesDAO.excluirFilme(id);
		
		request.setAttribute("status", excluiu);
		request.setAttribute("operacao", "excluído");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/status_insercao.jsp");
		dispatcher.forward(request, response);
	}
	
	
	private void buscarFilme (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	System.out.println("Controller: buscarFilme");
		
		int id = Integer.parseInt(request.getParameter("id_filme"));
		Filme filme = new Filme();
		filme = filmesDAO.procurarFilme(id);
		
		List<Filme> listaFilmes = new ArrayList();
		listaFilmes.add(filme);
		
		request.setAttribute("lista_filmes", listaFilmes);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/view_filmes.jsp");
		dispatcher.forward(request, response);
	}
		
	
	private void cadastrarFilme(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		System.out.println("Controller: cadastrarFilme");
		
		String nome_filme = request.getParameter("nome_filme");
		String genero = request.getParameter("genero");
		int avaliacao = Integer.parseInt(request.getParameter("avaliacao"));
		boolean inseriu = filmesDAO.inserirFilme(nome_filme, genero, avaliacao );
		
		request.setAttribute("status", inseriu);
		request.setAttribute("operacao", "inserida");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/status_insercao.jsp");
		dispatcher.forward(request, response);
		
	}


	private void listarFilmes(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("Controller: listarFilmes");
		
		List<Filme> listarFilmes = new ArrayList<>();
		listarFilmes = filmesDAO.consultaFilme();
		
		// Adiciona lista de tarefas no objeto "request"
		request.setAttribute("lista_filmes", listarFilmes);
		
		// Cria o objeto de dispatcher e indica a página que receberá a requisição
		RequestDispatcher dispatcher = request.getRequestDispatcher("/view_filmes.jsp");

		// Enviar a resposta para o JSP
		dispatcher.forward(request, response);
	}

}
