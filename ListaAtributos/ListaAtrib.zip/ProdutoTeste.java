public class ProdutoTeste {
	public static void main (Streing[]args){
		
		Produto = new Produto(int num , String nom , int qtd , double pre);
		return Produto ;
		
		public void adicionaProduto {
		
		if (qtdDisponivel>1){
			qtdDisponivel = adicionaProduto;
		}
		else{
			System.out.printf("Valor inválivo");
		}
		}
		public void getQtdDisponível( ) {
		
			int getQtd;
			
		}
		
		produto p = new produto ();
		p.QtdDisponivel ();
		
		public void alteraPreco (){
		    Alterapreco = pre;
			produto p = new produto ();
			p.alteraPreco ();
		}
		
		Produto = new Produto2 ();
		
		int setNumero (){
			System.out.printf("\nEntre com o numero do produto:");
			
		}
		String setNome(){
			System.out.printf("\nEntre com o nome do produto:");
			
		}
		int setQtdDisponivel (){
			System.out.printf("\nInforme a quantidade:");
			
		}		
		double setpreco (){
			System.out.printf("\nInforme o preço:");
			
		}		
		
		produto p = new produto () ;
		p.mostraDados();
	}
}	
		
		