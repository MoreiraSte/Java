
public class JogoVelhaTestadadora {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JogoVelha jogo = new JogoVelha();
		
		jogo.iniciarJogo();
	}

}
