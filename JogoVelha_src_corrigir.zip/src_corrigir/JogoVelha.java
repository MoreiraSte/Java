import java.util.Scanner;

/* Um simples Jogo da Velha - Tic Tac Toe game. 
	Este jogo e realizado entre o jogador(usu�rio) e o
	computador.
	O jogador escolhe onde marcar e depois o computador joga
	Para o jogador define a sua posi��o escolhendo uma coordenada (linha, coluna) 
	O Jogadar eh representado por X na tela e
	Computador representado por O.
 */

public class JogoVelha {

	private char [][]matriz;
	Scanner tec;

	//inicializa a matriz
	public JogoVelha()
	{
		tec = new Scanner(System.in);

		inicializaMatriz();

	}

	// Cria e inicializa a matriz com espaco em branco ' '.
	private void inicializaMatriz() {

		int linha, col; 

		matriz = new char[3][3]; // cria a matriz 3 x 3

		// inicializa a matriz com espaco em branco ' ' 
		// para indicar que esta vazia e que nem o usuario nem o computador marcaram esta posicao
		for( linha = 0 ; linha < 3; linha++) {
			for( col = 0 ; col < 3 ; col++) 
				matriz[linha][col] = ' ';
				
		} 
		
	}

	// todo a l�gica do jogo esta neste m�todo
	public void iniciarJogo()
	{
		char situacao; 

		System.out.printf("Este � o jogo da velha - Tic Tac Toe.\n");
		System.out.printf("Voce jogara contra o computador.\n");

		situacao =  ' '; 
		inicializaMatriz(); 
		
		do {
			desenhaMatriz();
			usuarioJoga();
			situacao = verifica(); // verifice tem ganhador

			if(situacao != ' ') 
				break;  // ganhador!

			computadorJoga();
			situacao = verifica(); // verifice tem ganhador
		} while(situacao == ' '); 

		if( situacao =='X') 
			System.out.printf("Voc� ganhou!\n");
		else 
			System.out.printf("Voc� perdeu!!!!Perdeu para este computador vai ganhar de quem kkkk\n"); 

		desenhaMatriz(); /* show final positions */
	}

	// Desenha a matriz sobre a tela
	private void desenhaMatriz()
	{
		int t; 

		for(t = 0; t < 3; t++) {

			System.out.printf(" %c | %c | %c ",matriz[t][0], matriz[t][1], matriz [t][2]);

			if( t != 2 ) 
				System.out.printf("\n---|---|---\n");
		}

		System.out.printf("\n");
	} 

	// Jogador faz uma jogada - escolhe uma posicao X
	private void usuarioJoga()
	{
		int x, y; 

		System.out.printf("Sua vez de jogar, entre com as suas coordenadas (linha,coluna) "
				+ "\nseparado por espaco): ");
		
		x= tec.nextInt(); 
		y= tec.nextInt();

		x--; // ? 
		y--; // ?

		if( matriz[x][y] != ' ') {
			System.out.printf("Movimento invalido, tente novamente.\n");
			usuarioJoga();
		}
		else 
			matriz[x][y] = 'X';
	} 

	// Verifica se existe um ganhador
	private char verifica()
	{
		int linha, col; 

		// verifica linhas 
		for(linha = 0; linha < 3; linha++)  
			if( ( matriz[linha][0] == matriz[linha][1]) && ( matriz[linha][0] == matriz[linha][2]) ) 
				return matriz[linha][0];

		// verifica colunas
		for(col = 0; col < 3; col++)  
			if( (matriz[0][col] == matriz[1][col]) && (matriz[0][col] == matriz[2][col]) ) 
				return matriz[0][col];

		// testa diagonais 
		if( (matriz[0][0] == matriz[1][1]) && (matriz[1][1]==matriz[2][2]) )
			return matriz[0][0]; 

		if( (matriz[0][2] == matriz[1][1]) && (matriz[1][1]==matriz[2][0]) )
			return matriz[0][2]; 

		return ' ';
	}   

	// Computador realiza uma jogoda
	private void computadorJoga()
	{
		int i, j; 

		for( i = 0; i < 3; i++) 
			for(j = 0; j < 3; j++)
				if(matriz[i][j] == ' ') 
					break;
		
			

		if( i * j == 9)  {
			System.out.printf("FIM JOGO\n");
			return;
		}
		else
			matriz[i][j] = 'O';
	} 

}
