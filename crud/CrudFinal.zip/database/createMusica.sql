create table musica(
 codigo int primary key  not null,
 nome varchar (30) not null,
 cantor varchar (50) not null,
 estilo varchar (20) not null
 );