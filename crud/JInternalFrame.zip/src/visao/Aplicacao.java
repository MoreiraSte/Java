package visao;

public class Aplicacao {

	public static void main(String[] args) {

		MusicaVisao m = new MusicaVisao();

		m.menu();
	}

}
