package visao;

public class MusicaVisaoTestadora {

	public static void main(String[] args) {

		MusicaVisao musicavisao = new MusicaVisao();
		
		musicavisao.menu();

	}

}

