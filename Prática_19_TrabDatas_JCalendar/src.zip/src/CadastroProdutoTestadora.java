import javax.swing.JFrame;

public class CadastroProdutoTestadora {

	public static void main(String[] args) {

		CadastroProdutoCalendar p = new CadastroProdutoCalendar();
		
	//	alunoAddFrame2.setResizable(false);
		p.setSize( 340, 300 ); // set frame size
		
		p.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );
		
		p.setVisible(true);

	}

}
